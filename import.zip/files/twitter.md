---
output:
  html_document: default
  word_document: default
---

#ジョージ

@EFC_Jayy UKIP



#Yara-ma-yha-who

RT @Corbynator2: @jeremycorbyn Reaction from people at the Watford Rally:
“We believe in Jeremy Corbyn!”
“We need Jeremy!”
\#GE2017… 



#Openly classist

RT @ryvr: Stephen Hawking, the world’s smartest man, backs Jeremy Corbyn https://t.co/2kl3ayLd44 \#TuesdayThoughts



#Stu

RT @TheGreenParty: How you cast your vote will shape the future. Every single vote counts. Tomorrow, \#VoteGreen2017. https://t.co/QgEdxfnDCK



#Ousama

RT @UKLabour: \#VoteLabour today for a fairer Britain. Find out where to vote, then share this ↓ https://t.co/953WYc2p0c https://t.co/kDnXiJ…



