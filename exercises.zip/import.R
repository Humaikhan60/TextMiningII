# TXT
char_txt <- readLines("files/twitter.txt", encoding = "UTF-8")
print(char_txt)

# JSON
require(jsonlite)
lis_json <- read_json("files/twitter_single.json")
char_json <- lis_json$text
usrid_json <- lis_json$user$id
char_json
print(usrid_json)

# PDF
require(pdftools)
char_pdf <- pdf_text("files/twitter.pdf")
char_pdf

# XML
require(XML)
dom_xml <- xmlParse("files/twitter.xml", encoding = "UTF-8")
char_xml <- xmlValue(getNodeSet(dom_xml, "//extended_tweet/full_text"))
#dom_xml
char_xml

# HTML
require(XML)
dom_html <- htmlParse("files/twitter.html", encoding = "UTF-8")
char_html <- unlist(xmlApply(getNodeSet(dom_html, "//body//div[@class='section level1']/p"), xmlValue))
char_html

# MS Word
install.packages("qdapTools")
require(qdapTools)
char_word <- read_docx("files/twitter.docx")
char_word

# MS Word (hack)
require(XML)
unzip("files/twitter.docx", exdir = "files/unzip")
dom_word <- xmlParse("files/unzip/word/document.xml", encoding = "UTF-8")
char_word2 <- unlist(xmlApply(getNodeSet(dom_word, "//w:document"), xmlValue))
char_word2
